package com.cg.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDao {

	Connection con = null;
	PreparedStatement ps = null;
	
	public Connection getConnection()
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			String url="jdbc:oracle:thin:@localhost:1521:XE";
			String user="system";
			String pass="Capgemini123";
			
			con=DriverManager.getConnection(url, user, pass);
			return con;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return con;
		
	}
	
	public int add(String username,String password,String mail,String mobile)
	{
		 con=getConnection();
		 
		 String sql="insert into user_details values(?,?,?,?)";
		 
		 try {
			ps=con.prepareStatement(sql);
			
			ps.setString(1, username);
			ps.setString(2,password);
			ps.setString(3,mail);
			ps.setString(4,mobile);
			
			int n= ps.executeUpdate();
			
		
			return n;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		 
		 return 0;
	}
	
	
	public boolean getDetails(String password)
	{
		con = getConnection();
		
		String sql="Select username from user_details where password=?";
		
		try {
			ps= con.prepareStatement(sql);
			
			ps.setString(1,password);
			
			ResultSet pass=ps.executeQuery();
			
			return pass.next();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		
		return false;
	}
	
	public int addProductDetails(String id,String produt_name,String product_model,String product_price)
	{
			con=getConnection();
		 
		 String sql="insert into product_details values(?,?,?,?)";
		
		 try {
				ps=con.prepareStatement(sql);
				
				ps.setString(1, id);
				ps.setString(2,produt_name);
				ps.setString(3,product_model);
				ps.setString(4,product_price);
				
				int n= ps.executeUpdate();
				
			
				return n;
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
			 
		
		
		return 0;
	}
	
	
	
}
