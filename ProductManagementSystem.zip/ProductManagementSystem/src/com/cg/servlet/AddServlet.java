package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dao.UserDao;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		PrintWriter out= response.getWriter();
		
		String id=request.getParameter("product_id");
		
		String produt_name = request.getParameter("product_name");
		
		String product_model= request.getParameter("product_model");
		
		String product_price=request.getParameter("product_price");
		
		
		
		UserDao dao= new UserDao();
		
		int n= dao.addProductDetails(id, produt_name, product_model, product_price);
		
		if(n>0)
		{
			out.println("Successfully entered product details");
			RequestDispatcher rd = request.getRequestDispatcher("home.jsp");
			rd.include(request,response);
		}
		else
		{
			out.println("something went wrong");
			RequestDispatcher rd = request.getRequestDispatcher("addproducts.jsp");
			rd.include(request, response);
		}
		
		
		
		
		
		
	}

}
