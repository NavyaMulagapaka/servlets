package com.cg.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html");
		
		PrintWriter out= response.getWriter();
		
		String username=request.getParameter("user");
				
		String password=request.getParameter("pass");
		
		HttpSession hs=request.getSession();
		
		hs.setAttribute("uname", username);
		
		
		
		Cookie c1= new Cookie("uname", username);
		
		Cookie c2= new Cookie("pass", password);
		
		response.addCookie(c1);
		
		response.addCookie(c2);
		
		
		ServletContext sc= getServletContext();
		
		try
		{
			Class.forName(sc.getInitParameter("driver_class"));
			
			String url= sc.getInitParameter("url");
			
			String user=sc.getInitParameter("user");
			
			String pass= sc.getInitParameter("password");
			
			Connection con = DriverManager.getConnection(url, user, pass);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		ServletConfig s = getServletConfig();
		
		if(username.equals(s.getInitParameter("username"))&& password.equals(s.getInitParameter("password")))
		{
			/*response.sendRedirect("https://www.google.com/");*/
			
			/*RequestDispatcher rd = request.getRequestDispatcher("https://www.google.com/");
			
			rd.forward(request,response);*/
			
			
			response.sendRedirect("welcome.jsp");
			
		}
		else
		{
			out.println("user not registered. Please register");
			
			RequestDispatcher rd = request.getRequestDispatcher("register.jsp");
			
			rd.include(request, response);
		}
		
	
		
		
	}

}
